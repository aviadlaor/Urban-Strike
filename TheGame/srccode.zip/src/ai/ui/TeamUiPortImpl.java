package ai.ui;

import ai.model.Enemy;
import ai.model.Player;
import shared.ui_ports.TeamUiPort;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferInt;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class TeamUiPortImpl extends TeamUiPort {

    private static final int    SCREEN_W   = 1280;
    private static final int    SCREEN_H   = 720;
    private static final double FOV        = Math.PI / 3;    // 60°
    // World bounds kept in lock-step with UrbanStrikeBackend.SCREEN_W/H so enemy
    // spawns (placed in GameWorld.initWorld using those constants) stay inside the
    // raycast world and within the player's movement clamp.
    private static final double WORLD_W    = 1280.0;
    private static final double WORLD_H    = 720.0;
    // Projection constant: wallHeight = PROJ_SCALE / perpDist.
    private static final double PROJ_SCALE = 130_000.0;
    private static final int    TEX_SIZE   = 64;   // procedural brick texture resolution

    // ── Push-based state from backend ────────────────────────────────────────
    private double  playerX, playerY;
    private Map<Integer, double[]> enemies   = new HashMap<>();
    private Map<Integer, double[]> itemPos   = new HashMap<>(); // id → {x, y}
    private Map<Integer, String>   itemTypes = new HashMap<>(); // id → "Medkit"|"AmmoBox"
    private int     health        = 100;
    private int     score         = 0;
    private int     ammo          = 30;
    private String  message       = "";
    private boolean showFireFlash = false;

    // ── US-08 Game Over + US-02 per-enemy health feedback ────────────────────
    private boolean gameOver   = false;
    private int     finalScore = 0;
    private final Map<Integer, Integer> enemyHealthPercent = new HashMap<>();

    // ── Manual item pickup prompt ─────────────────────────────────────────────
    private String nearbyItemName = "";

    // ── Procedural textures + pixel-buffer ───────────────────────────────────
    private final int[][]       wallTex   = new int[TEX_SIZE][TEX_SIZE];
    private final BufferedImage offscreen = new BufferedImage(SCREEN_W, SCREEN_H, BufferedImage.TYPE_INT_RGB);

    // ── Direct model references set once at startGame ────────────────────────
    private final JPanel    panel;
    private Player          gamePlayer;
    private List<Enemy>     gameEnemies = new ArrayList<>();

    public TeamUiPortImpl(JPanel panel) { this.panel = panel; generateWallTexture(); }

    private void generateWallTexture() {
        Random rng = new Random(42);
        for (int y = 0; y < TEX_SIZE; y++) {
            for (int x = 0; x < TEX_SIZE; x++) {
                boolean mortarRow = (y % 8 == 0);
                int brickRow      = y / 8;
                boolean mortarCol = ((x + brickRow * 16) % 32 == 0);
                if (mortarRow || mortarCol) {
                    int v = 88 + rng.nextInt(18);
                    wallTex[y][x] = (v << 16) | ((v - 4) << 8) | (v - 8);
                } else {
                    int r = 138 + rng.nextInt(36);
                    int g = 66  + rng.nextInt(24);
                    int b = 46  + rng.nextInt(22);
                    wallTex[y][x] = (r << 16) | (g << 8) | b;
                }
            }
        }
    }

    public void setGameWorld(Player player, List<Enemy> enemies) {
        this.gamePlayer  = player;
        this.gameEnemies = enemies;
    }

    // ── TeamUiPort interface ─────────────────────────────────────────────────

    @Override public void method1(int id) {}

    @Override public void showPlayer(double x, double y)  { playerX = x; playerY = y; panel.repaint(); }
    @Override public void updatePlayer(double x, double y) { playerX = x; playerY = y; panel.repaint(); }

    @Override public void addEnemy(int id, double x, double y) {
        enemies.put(id, new double[]{x, y}); panel.repaint();
    }

    @Override public void updateEnemy(int id, double x, double y) {
        double[] pos = enemies.get(id);
        if (pos != null) { pos[0] = x; pos[1] = y; panel.repaint(); }
    }

    @Override public void removeEnemy(int id)  { enemies.remove(id); panel.repaint(); }
    @Override public void updateHealth(int h)  { this.health = h; panel.repaint(); }
    @Override public void updateScore(int s)   { this.score  = s; panel.repaint(); }
    @Override public void updateAmmo(int a)    { this.ammo   = a; panel.repaint(); }

    @Override public void showFireEffect() {
        showFireFlash = true; panel.repaint();
        Timer t = new Timer(80, e -> { showFireFlash = false; panel.repaint(); });
        t.setRepeats(false); t.start();
    }

    @Override public void showMessage(String msg) {
        this.message = msg; panel.repaint();
        Timer t = new Timer(2000, e -> { this.message = ""; panel.repaint(); });
        t.setRepeats(false); t.start();
    }

    @Override public void log(String message) { System.out.println("[Game] " + message); }

    @Override public void addItem(int id, double x, double y, String type) {
        itemPos.put(id, new double[]{x, y});
        itemTypes.put(id, type);
        panel.repaint();
    }

    @Override public void removeItem(int id) {
        itemPos.remove(id);
        itemTypes.remove(id);
        panel.repaint();
    }

    @Override public void showPickupMessage(String msg) { showMessage(msg); }

    // ── US-08: Game Over ─────────────────────────────────────────────────────

    @Override public void triggerGameOverScreen(int finalScore) {
        this.gameOver   = true;
        this.finalScore = finalScore;
        panel.repaint();
    }

    @Override public void triggerRestartGame() {
        this.gameOver       = false;
        this.health         = 100;
        this.ammo           = 30;
        this.score          = 0;
        this.nearbyItemName = "";
        enemyHealthPercent.clear();
        panel.repaint();
    }

    // ── Manual item pickup: called from backend via cast ─────────────────────

    public void setNearbyItem(String itemName) {
        this.nearbyItemName = (itemName == null) ? "" : itemName;
        panel.repaint();
    }

    // ── US-02: visual hit feedback ───────────────────────────────────────────

    @Override public void updateEnemyHealth(int enemyId, int healthPercent) {
        enemyHealthPercent.put(enemyId, healthPercent);
        panel.repaint();
    }

    // ── Entry point called by GamePanel.paintComponent ───────────────────────

    public void render(Graphics g) {
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        if (gameOver) {
            renderGameOver(g2);   // US-08: freeze world, show full-screen overlay
            return;
        }

        if (gamePlayer == null) {
            g2.setColor(Color.BLACK);
            g2.fillRect(0, 0, SCREEN_W, SCREEN_H);
            g2.setColor(Color.GRAY);
            g2.setFont(new Font("Arial", Font.PLAIN, 18));
            g2.drawString("Waiting for game state...", 20, 50);
            return;
        }

        renderWorld(g2);   // Phase A: 3D raycasted scene
        renderHUD(g2);     // Phase B: HUD overlay — always on top
    }

    // ── US-08: full-screen Game Over overlay ─────────────────────────────────

    private void renderGameOver(Graphics2D g2) {
        g2.setColor(Color.BLACK);
        g2.fillRect(0, 0, SCREEN_W, SCREEN_H);

        drawCentered(g2, "GAME OVER",            new Font("Arial", Font.BOLD,  72), Color.RED,        SCREEN_H / 2 - 60);
        drawCentered(g2, "FINAL SCORE: " + finalScore, new Font("Arial", Font.BOLD,  36), Color.WHITE,      SCREEN_H / 2 + 10);
        drawCentered(g2, "Press R to Restart",   new Font("Arial", Font.PLAIN, 22), Color.LIGHT_GRAY, SCREEN_H / 2 + 70);
    }

    private void drawCentered(Graphics2D g2, String text, Font font, Color color, int y) {
        g2.setFont(font);
        g2.setColor(color);
        int textW = g2.getFontMetrics().stringWidth(text);
        g2.drawString(text, (SCREEN_W - textW) / 2, y);
    }

    // ── Phase A: FPS raycasted world ─────────────────────────────────────────

    private void renderWorld(Graphics2D g2) {
        double px = gamePlayer.getX();
        double py = gamePlayer.getY();
        double pa = gamePlayer.getAngle();

        // Write ceiling, floor and walls into a pixel buffer — one pass per column
        int[] pixels     = ((DataBufferInt) offscreen.getRaster().getDataBuffer()).getData();
        int[] wallHeights = new int[SCREEN_W];

        for (int col = 0; col < SCREEN_W; col++) {
            double rayAngle = pa - FOV / 2.0 + (col / (double) SCREEN_W) * FOV;
            double[] hit    = castRayFull(px, py, rayAngle);
            double perpDist = Math.max(1.0, hit[0] * Math.cos(rayAngle - pa));

            int wallH   = Math.min(SCREEN_H, (int)(PROJ_SCALE / perpDist));
            wallHeights[col] = wallH;
            int wallTop = (SCREEN_H - wallH) / 2;
            int wallBot = wallTop + wallH;

            // texture column from hit fraction
            int texX = Math.min(TEX_SIZE - 1, (int)(hit[1] * TEX_SIZE));
            float fog = Math.min(1.0f, (float)(perpDist / 600.0));

            for (int y = 0; y < SCREEN_H; y++) {
                int packed;
                if (y < wallTop) {
                    // Dark urban sky: near-black at top, slightly lighter toward horizon
                    float t = (wallTop > 0) ? (float) y / wallTop : 0f;
                    int r = (int)(8  + 22 * t);
                    int gv= (int)(8  + 18 * t);
                    int b = (int)(18 + 38 * t);
                    packed = (r << 16) | (gv << 8) | b;
                } else if (y >= wallBot) {
                    // Asphalt floor: grey with deterministic per-pixel noise
                    float t = (SCREEN_H > wallBot) ? (float)(y - wallBot) / (SCREEN_H - wallBot) : 1f;
                    int v = (int)(60 - 18 * t);
                    v += ((col * 7 + y * 13) & 0xF) - 8;   // cheap noise, no Random call
                    v = Math.max(0, Math.min(255, v));
                    packed = (v << 16) | (v << 8) | v;
                } else {
                    // Brick wall with distance fog
                    int texY = Math.min(TEX_SIZE - 1, (int)((y - wallTop) * TEX_SIZE / (double) wallH));
                    int c  = wallTex[texY][texX];
                    int r  = (int)(((c >> 16) & 0xFF) * (1 - fog) + 8 * fog);
                    int gv = (int)(((c >>  8) & 0xFF) * (1 - fog) + 8 * fog);
                    int b  = (int)(( c        & 0xFF) * (1 - fog) + 8 * fog);
                    packed = (r << 16) | (gv << 8) | b;
                }
                pixels[y * SCREEN_W + col] = packed;
            }
        }

        g2.drawImage(offscreen, 0, 0, null);
        drawEnemySprites(g2, px, py, pa, wallHeights);
        drawItemSprites(g2, px, py, pa, wallHeights);

        // Fire flash: bright crosshair flare
        if (showFireFlash) {
            g2.setColor(new Color(255, 200, 0, 200));
            g2.setStroke(new BasicStroke(3f));
            int cx = SCREEN_W / 2, cy = SCREEN_H / 2;
            g2.drawLine(cx - 16, cy, cx + 16, cy);
            g2.drawLine(cx, cy - 16, cx, cy + 16);
        }
    }

    /** Returns {euclidean distance, texFrac 0..1 along the hit wall face}. */
    private double[] castRayFull(double px, double py, double rayAngle) {
        double dx  = Math.cos(rayAngle);
        double dy  = Math.sin(rayAngle);
        double minT    = Double.MAX_VALUE;
        double texFrac = 0.0;

        if (dx < -1e-6) {
            double t = -px / dx, hy = py + dy * t;
            if (t > 0 && inRange(hy, 0, WORLD_H) && t < minT) { minT = t; texFrac = hy / WORLD_H; }
        }
        if (dx >  1e-6) {
            double t = (WORLD_W - px) / dx, hy = py + dy * t;
            if (t > 0 && inRange(hy, 0, WORLD_H) && t < minT) { minT = t; texFrac = hy / WORLD_H; }
        }
        if (dy < -1e-6) {
            double t = -py / dy, hx = px + dx * t;
            if (t > 0 && inRange(hx, 0, WORLD_W) && t < minT) { minT = t; texFrac = hx / WORLD_W; }
        }
        if (dy >  1e-6) {
            double t = (WORLD_H - py) / dy, hx = px + dx * t;
            if (t > 0 && inRange(hx, 0, WORLD_W) && t < minT) { minT = t; texFrac = hx / WORLD_W; }
        }
        double dist = (minT == Double.MAX_VALUE) ? 1000.0 : minT;
        return new double[]{ dist, texFrac };
    }

    /** Legacy single-return overload kept for any future callers. */
    private double castRay(double px, double py, double rayAngle) {
        double dx  = Math.cos(rayAngle);
        double dy  = Math.sin(rayAngle);
        double min = Double.MAX_VALUE;

        if (dx < -1e-6) {                                    // left  wall  x=0
            double t = -px / dx;
            if (t > 0 && inRange(py + dy * t, 0, WORLD_H)) min = Math.min(min, t);
        }
        if (dx >  1e-6) {                                    // right wall  x=WORLD_W
            double t = (WORLD_W - px) / dx;
            if (t > 0 && inRange(py + dy * t, 0, WORLD_H)) min = Math.min(min, t);
        }
        if (dy < -1e-6) {                                    // top   wall  y=0
            double t = -py / dy;
            if (t > 0 && inRange(px + dx * t, 0, WORLD_W)) min = Math.min(min, t);
        }
        if (dy >  1e-6) {                                    // bottom wall y=WORLD_H
            double t = (WORLD_H - py) / dy;
            if (t > 0 && inRange(px + dx * t, 0, WORLD_W)) min = Math.min(min, t);
        }

        return min == Double.MAX_VALUE ? 1000.0 : min;
    }

    private static boolean inRange(double v, double lo, double hi) {
        return v >= lo && v <= hi;
    }

    private void drawEnemySprites(Graphics2D g2, double px, double py,
                                   double pa, int[] wallHeights) {
        List<Enemy> snapshot = new ArrayList<>(gameEnemies);
        // Farthest first so closer soldiers paint over distant ones
        snapshot.sort((a, b) -> Double.compare(b.distanceTo(px, py), a.distanceTo(px, py)));

        for (Enemy enemy : snapshot) {
            if (!enemy.isAlive()) continue;

            double relX = enemy.getX() - px;
            double relY = enemy.getY() - py;
            double dist = Math.sqrt(relX * relX + relY * relY);
            if (dist < 1) continue;

            double angleToEnemy = Math.atan2(relY, relX);
            double diff = angleToEnemy - pa;
            while (diff >  Math.PI) diff -= 2 * Math.PI;
            while (diff < -Math.PI) diff += 2 * Math.PI;

            if (Math.abs(diff) > FOV / 2.0 + 0.2) continue;

            int screenX    = (int)(SCREEN_W / 2.0 + SCREEN_W * diff / FOV);
            int spriteH    = Math.min(SCREEN_H, (int)(PROJ_SCALE / dist));
            int spriteW    = spriteH;
            int spriteTop  = (SCREEN_H - spriteH) / 2;
            int spriteLeft = screenX - spriteW / 2;

            boolean inFront = false;
            for (int col = Math.max(0, spriteLeft); col < Math.min(SCREEN_W, spriteLeft + spriteW); col++) {
                if (wallHeights[col] <= spriteH) { inFront = true; break; }
            }
            if (!inFront) continue;

            drawSoldier(g2, screenX, spriteTop, spriteW, spriteH, dist);

            // US-02: health bar 8px above sprite top
            int hpPct = enemyHealthPercent.getOrDefault(enemy.getId(), 100);
            int barY  = spriteTop - 8;
            g2.setColor(new Color(40, 40, 40));
            g2.fillRect(spriteLeft, barY, spriteW, 5);
            Color hpColor = hpPct > 50 ? new Color(50, 200, 80) :
                            hpPct > 25 ? new Color(220, 180, 0) : new Color(220, 50, 50);
            g2.setColor(hpColor);
            g2.fillRect(spriteLeft, barY, (int)(spriteW * hpPct / 100.0), 5);
        }
    }

    private void drawSoldier(Graphics2D g2, int cx, int top, int w, int h, double dist) {
        if (w < 4 || h < 4) return;

        int shade = Math.max(30, 200 - (int)(dist / 3.0));

        // Body proportions
        int headH = Math.max(2, h * 18 / 100);
        int bodyH = Math.max(2, h * 33 / 100);
        int armH  = Math.max(1, h * 28 / 100);
        int legH  = Math.max(1, h - headH - bodyH);
        int bodyW = Math.max(2, w * 40 / 100);
        int headW = Math.max(2, w * 28 / 100);
        int armW  = Math.max(1, w * 14 / 100);
        int legW  = Math.max(1, w * 17 / 100);

        int headX = cx - headW / 2,   headY = top;
        int bodyX = cx - bodyW / 2,   bodyY = headY + headH;
        int legY  = bodyY + bodyH;

        // Legs — dark tactical trousers
        g2.setColor(new Color(shade * 27 / 100, shade * 31 / 100, shade * 21 / 100));
        g2.fillRect(bodyX,                   legY, legW, legH);
        g2.fillRect(bodyX + bodyW - legW,    legY, legW, legH);

        // Body — military olive jacket
        g2.setColor(new Color(shade * 40 / 100, shade * 48 / 100, shade * 27 / 100));
        g2.fillRect(bodyX, bodyY, bodyW, bodyH);

        // Arms
        g2.fillRect(bodyX - armW, bodyY, armW, armH);
        g2.fillRect(bodyX + bodyW, bodyY, armW, armH);

        // Head — skin tone
        g2.setColor(new Color(
            Math.min(255, shade * 70 / 100 + 28),
            Math.min(255, shade * 54 / 100 + 18),
            Math.min(255, shade * 40 / 100 +  8)));
        g2.fillOval(headX, headY, headW, headH);

        // Helmet — dark grey dome over upper half of head
        g2.setColor(new Color(shade * 27 / 100, shade * 27 / 100, shade * 27 / 100));
        g2.fillArc(headX - 1, headY - 2, headW + 2, headH / 2 + 3, 0, 180);

        // Gun barrel extending from right arm (only when sprite is large enough)
        if (h > 28) {
            g2.setColor(new Color(35, 35, 35));
            int gunY   = bodyY + armH / 2;
            int gunLen = Math.max(2, w / 6);
            g2.fillRect(bodyX + bodyW + armW, gunY, gunLen, Math.max(1, h / 32));
        }
    }

    private void drawItemSprites(Graphics2D g2, double px, double py,
                                  double pa, int[] wallHeights) {
        // Snapshot both maps together to stay consistent
        Map<Integer, double[]> posSnap  = new HashMap<>(itemPos);
        Map<Integer, String>   typeSnap = new HashMap<>(itemTypes);

        for (Map.Entry<Integer, double[]> entry : posSnap.entrySet()) {
            int    id   = entry.getKey();
            double[] pos = entry.getValue();
            String type  = typeSnap.getOrDefault(id, "");

            double relX = pos[0] - px;
            double relY = pos[1] - py;
            double dist = Math.sqrt(relX * relX + relY * relY);
            if (dist < 1) continue;

            double angleToItem = Math.atan2(relY, relX);
            double diff = angleToItem - pa;
            while (diff >  Math.PI) diff -= 2 * Math.PI;
            while (diff < -Math.PI) diff += 2 * Math.PI;

            if (Math.abs(diff) > FOV / 2.0 + 0.2) continue;

            int screenX   = (int)(SCREEN_W / 2.0 + SCREEN_W * diff / FOV);
            int spriteH   = Math.min(SCREEN_H / 4, (int)(PROJ_SCALE * 0.35 / dist));
            int spriteW   = spriteH;
            int spriteTop = SCREEN_H / 2;          // sit on the floor (horizon line)
            int spriteLeft = screenX - spriteW / 2;

            // Z-buffer: item is visible only where the wall is farther
            boolean visible = false;
            for (int col = Math.max(0, spriteLeft); col < Math.min(SCREEN_W, spriteLeft + spriteW); col++) {
                if (wallHeights[col] < SCREEN_H) { visible = true; break; }
            }
            if (!visible) continue;

            Color c = "Medkit".equals(type) ? new Color(50, 200, 80) : new Color(255, 200, 0);
            g2.setColor(c);
            g2.fillRect(spriteLeft, spriteTop, spriteW, spriteH);
            g2.setColor(Color.WHITE);
            g2.setStroke(new BasicStroke(1.5f));
            g2.drawRect(spriteLeft, spriteTop, spriteW, spriteH);
            g2.setFont(new Font("Arial", Font.BOLD, 9));
            g2.drawString("Medkit".equals(type) ? "M" : "A", screenX - 3, spriteTop + spriteH / 2 + 4);
        }
    }

    // ── Phase B: HUD overlay — always rendered last, always on top ───────────

    private void renderHUD(Graphics2D g2) {
        // Semi-transparent top bar
        g2.setColor(new Color(0, 0, 0, 160));
        g2.fillRect(0, 0, SCREEN_W, 36);

        g2.setFont(new Font("Arial", Font.BOLD, 15));

        // Health bar track + fill
        g2.setColor(Color.GRAY);
        g2.fillRoundRect(10, 8, 120, 18, 6, 6);
        Color hpColor = health > 50 ? new Color(50, 200, 80) :
                        health > 25 ? new Color(220, 180, 0) : new Color(220, 50, 50);
        g2.setColor(hpColor);
        g2.fillRoundRect(10, 8, (int)(120 * health / 100.0), 18, 6, 6);

        g2.setColor(Color.WHITE);
        g2.drawString("HP " + health, 16, 22);

        // Ammo display — orange and "--" while reloading
        boolean reloading = gamePlayer != null && gamePlayer.isReloading();
        if (reloading) {
            g2.setColor(new Color(255, 165, 0));
            g2.drawString("AMO -- / " + Player.MAX_AMMO, 145, 22);
        } else {
            g2.setColor(Color.WHITE);
            g2.drawString("AMO " + ammo + " / " + Player.MAX_AMMO, 145, 22);
        }

        g2.setColor(new Color(255, 215, 0));
        g2.drawString("SCORE " + score, SCREEN_W - 130, 22);

        // RELOADING... center overlay
        if (reloading) {
            g2.setFont(new Font("Arial", Font.BOLD, 20));
            g2.setColor(new Color(0, 0, 0, 150));
            g2.fillRoundRect(SCREEN_W / 2 - 105, SCREEN_H / 2 + 28, 210, 36, 8, 8);
            g2.setColor(new Color(255, 165, 0));
            g2.drawString("RELOADING...", SCREEN_W / 2 - 88, SCREEN_H / 2 + 52);
        }

        // "Press E to pickup" prompt — shown when player is next to an item
        if (!nearbyItemName.isEmpty()) {
            String prompt = "Press E to pick up " + nearbyItemName;
            g2.setFont(new Font("Arial", Font.BOLD, 18));
            int pw = g2.getFontMetrics().stringWidth(prompt);
            int px2 = (SCREEN_W - pw) / 2;
            int py2 = SCREEN_H * 3 / 4;
            g2.setColor(new Color(0, 0, 0, 160));
            g2.fillRoundRect(px2 - 10, py2 - 22, pw + 20, 30, 8, 8);
            g2.setColor(new Color(255, 220, 60));
            g2.drawString(prompt, px2, py2);
        }

        // Crosshair
        g2.setColor(new Color(255, 255, 255, 160));
        g2.setStroke(new BasicStroke(1.5f));
        int cx = SCREEN_W / 2, cy = SCREEN_H / 2;
        g2.drawLine(cx - 8, cy, cx - 3, cy);
        g2.drawLine(cx + 3, cy, cx + 8, cy);
        g2.drawLine(cx, cy - 8, cx, cy - 3);
        g2.drawLine(cx, cy + 3, cx, cy + 8);

        // Timed message (e.g. "Game Over")
        if (!message.isEmpty()) {
            g2.setColor(new Color(0, 0, 0, 140));
            g2.fillRoundRect(SCREEN_W / 2 - 130, SCREEN_H - 60, 260, 30, 8, 8);
            g2.setColor(Color.WHITE);
            g2.setFont(new Font("Arial", Font.BOLD, 14));
            g2.drawString(message, SCREEN_W / 2 - 120, SCREEN_H - 40);
        }
    }
}
