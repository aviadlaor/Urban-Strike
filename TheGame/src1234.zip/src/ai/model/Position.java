package ai.model;

public class Position {
    private double x;
    private double y;

    public Position(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public double getX() { return x; }
    public double getY() { return y; }
    public void setX(double x) { this.x = x; }
    public void setY(double y) { this.y = y; }

    public double distanceTo(double px, double py) {
        double dx = x - px, dy = y - py;
        return Math.sqrt(dx * dx + dy * dy);
    }
}
